import uvicorn
from app import app

uvicorn.run(app, port=8000)
